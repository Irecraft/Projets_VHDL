# USB-Blaster-Driver-for-DE10-lite
- Download .zip file [here](https://github.com/sudhamshu091/USB-Blaster-Driver-for-DE10-lite/archive/refs/heads/main.zip)<br>
- Extract this folder and copy <code>usb-blaster</code> folder which contanis <code>x32</code> and <code>x64</code> folders, <code>licence.txt</code>, <code>usbblstr security catalog and setup information</code> into <code>drivers</code> in Quartus installation folder
  (For me it is <code>C:/IntelFPGA_lite/20.1/quartus/drivers</code>
in Intel Quartus standard it will be <code>C:/IntelFPGA/20.1/quartus/drivers</code>)<br>
- Once copied you can update the driver, it can be found in <code>device manager</code> under <code>other devices</code> or simply you can run <code>Dpinst</code> in drivers directory.
